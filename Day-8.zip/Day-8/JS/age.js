function sayhello(age,name){
    document.write(name+"is"+age+"year Old");
}