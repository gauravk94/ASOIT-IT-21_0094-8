function msg() {
    alert("Hello world!");
}